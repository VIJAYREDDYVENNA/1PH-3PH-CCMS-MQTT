<div class="row d-flex align-items-center">
  <div class="col-12 p-0 ">
    <div class="row d-flex justify-content-end align-items-center">
      <div class="col-xl-3 col-lg-4 col-6 d-flex align-items-center">
        <?php
        include("phase-selection.php");
        ?>
      </div>
      <div class="col-xl-3 col-lg-4 col-6 d-flex align-items-center">
       <?php
       include("group_selection.php");
       ?>
     </div>
   </div>
 </div>
</div>