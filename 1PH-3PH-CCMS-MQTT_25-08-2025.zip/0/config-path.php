<?php
define('BASE_PATH', '../');
?>