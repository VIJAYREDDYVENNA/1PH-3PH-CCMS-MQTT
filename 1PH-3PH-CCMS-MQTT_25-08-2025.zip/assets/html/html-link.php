<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="generator" content="Hugo 0.122.0">
<link href="<?php echo BASE_PATH?>assets/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo BASE_PATH?>assets/css/date-range-picker.min.css" rel="stylesheet">
<link href="<?php echo BASE_PATH?>assets/css/sidebars.css" rel="stylesheet">
<link href="<?php echo BASE_PATH?>assets/css/istl-styles.css" rel="stylesheet">
<script src="<?php echo BASE_PATH?>assets/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo BASE_PATH?>assets/js/sidebars.js"></script>
<script src="<?php echo BASE_PATH?>assets/js/color-modes.js"></script>
<script src="<?php echo BASE_PATH?>assets/js/project/check-session.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.slim.min.js" ></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.9.1/font/bootstrap-icons.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
