
$(document).ajaxStop(function () {
	$("#pre-loader").fadeOut();
});
$(document).ready(function(){
	$("#pre-loader").fadeOut();
});


