<?php
define('BASE_PATH', '../');
define('BASE_PATH_1', '../../');
?>